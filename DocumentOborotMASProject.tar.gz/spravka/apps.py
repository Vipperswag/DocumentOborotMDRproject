from django.apps import AppConfig


class SpravkaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'spravka'
